export class Project{
    public id: number;
    public title :string;
    public content :string;
    
    public status : boolean = false;
    public finishDate : string;
}