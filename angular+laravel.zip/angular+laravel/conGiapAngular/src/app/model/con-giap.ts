export class ConGiap {
    public id: number;
    public name :string;
    public detail :string;
    public image : string;
  

}
