import { ConGiap } from './con-giap';

describe('ConGiap', () => {
  it('should create an instance', () => {
    expect(new ConGiap()).toBeTruthy();
  });
});
