import { Awesome } from './awesome';

describe('Awesome', () => {
  it('should create an instance', () => {
    expect(new Awesome()).toBeTruthy();
  });
});
