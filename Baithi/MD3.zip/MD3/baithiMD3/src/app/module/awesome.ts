export class Awesome {
    public id: number;
    public tag: string;
    public url: string;
    public descriptions: string;
}

